var title = 'BM - Pengajuan Diskon';

function lanjut_proses(d, o){
	location.href= 'diskon-pengajuan.php?dealer_id='+ d + '&order_id=' + o
}
