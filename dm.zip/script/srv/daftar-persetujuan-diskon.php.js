var title = 'Daftar Persetujuan Diskon Tambahan';

function lanjut_proses(d, o){
	location.href= 'diskon-persetujuan.php?dealer='+ d + '&order_id=' + o
}
