var title = 'Daftar Pengajuan Diskon Tambahan';

function lanjut_proses(d, o){
	location.href= 'transaksi-2.php?dealer='+ d + '&order_id=' + o
}
