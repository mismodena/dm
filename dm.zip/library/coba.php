<?php 

echo "Di dalam file coba folder library.";