<?

echo sha1("123");

?>