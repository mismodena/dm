<?
print_r($_SERVER);
?>